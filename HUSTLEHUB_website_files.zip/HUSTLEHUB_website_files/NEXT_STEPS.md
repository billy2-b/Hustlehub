# HUSTLEHUB next steps — phone-friendly

## Step 1 — Save and preview
1. Download and extract `HUSTLEHUB_website_files.zip` on your phone.
2. Open `index.html` to preview it if your phone offers a browser option. If local preview does not work, deploy it to a static host in the next step.

## Step 2 — Choose a free static host
Use a reputable static hosting provider that supports uploading a folder or connecting a Git repository. Follow its current upload/deploy instructions. Do not paste secret keys into the host's public source files.

## Step 3 — Connect Supabase
1. In Supabase, open Project Settings / API (menu names may change).
2. Copy the Project URL and the publishable/anon key.
3. In `app.js`, fill in `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
4. Do not use the `service_role` key in the browser.
5. Before enabling live listings, inspect the actual `jobs` table columns and its RLS policies; this starter assumes a `status` column with value `published`.

## Step 4 — Secure database
Your current project already has `profiles` and `jobs` tables with RLS enabled. Check their columns and create policies tailored to your admin-only job management plan. Do not make anonymous users able to edit jobs or profiles.

## Step 5 — Payment integration later
The current `mpesa-stk-push` function is not production-ready. Do not initiate payments until the backend has:
- authenticated and authorized payment requests,
- server-side input and amount validation against a trusted order,
- a reachable HTTPS callback endpoint,
- callback validation and transaction idempotency,
- persistent transaction records,
- safe handling of errors and logs,
- sandbox tests, then any required Safaricom approval for live credentials.
Never place Daraja secrets in `app.js` or share them in chat.

## Build one step at a time
Start by downloading and opening the files. Then tell ChatGPT what you see and we can deploy the static website before connecting database features.
