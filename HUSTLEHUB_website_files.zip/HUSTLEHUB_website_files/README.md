# HUSTLEHUB starter website

This is a mobile-friendly frontend starter for the HUSTLEHUB Kenyan job website.

## Files
- `index.html` — page structure
- `styles.css` — responsive green-and-gold design
- `app.js` — sample job listings, search, and optional Supabase Auth/jobs connection
- `supabase_schema_reference.sql` — reference only; inspect your existing tables before running SQL

## Important status
This is a starter, not a finished production website. Sample jobs are fictional examples for preview only. Authentication and live jobs remain disconnected until you configure Supabase. Referral rewards and M-Pesa payments are placeholders and are not enabled. The deployed Daraja Edge Function must be reviewed and completed before any payment testing or live use.

## Connect Supabase later
1. Open `app.js`.
2. Set `SUPABASE_URL` to your project URL.
3. Set `SUPABASE_ANON_KEY` to the Supabase publishable/anon key only.
4. Never put the `service_role` key or Daraja Consumer Secret in browser code.
5. Check the real `jobs` table column names and RLS policies before enabling the live jobs query.

## Preview
Open `index.html` in a browser or deploy the files to a static host. Some browsers restrict local-file behavior; a static hosting preview is recommended.

## Safety and trust
- Verify job listings and employers.
- Do not ask applicants to pay for access to a job listing unless the fee is clearly lawful, transparent, and reviewed by a trusted adult/adviser.
- Do not reward referrals mainly for bringing in new paying members.
- Do not treat an STK request as proof of payment. A secure server-side callback must validate and record confirmed transactions.
