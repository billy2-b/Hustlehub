/*
 * HUSTLEHUB starter frontend.
 * Supabase is optional until you add your project URL and publishable/anon key below.
 * NEVER put the Supabase service_role key or Daraja Consumer Secret in browser code.
 */
const SUPABASE_URL = ""; // Example: https://your-project-ref.supabase.co
const SUPABASE_ANON_KEY = ""; // Supabase publishable/anon key only; never service_role
let supabaseClient = null;
let selectedRole = "job_seeker";

const sampleJobs = [
  { title: "Secondary School Teacher", company: "Example Education Centre", location: "Nairobi, Kenya", type: "Full-time", category: "Education", description: "Sample listing for layout preview." },
  { title: "Customer Service Assistant", company: "Example Retail Group", location: "Mombasa, Kenya", type: "Full-time", category: "Customer service", description: "Sample listing for layout preview." },
  { title: "Office Administrator", company: "Example Business Services", location: "Nakuru, Kenya", type: "Contract", category: "Administration", description: "Sample listing for layout preview." },
  { title: "Sales Representative", company: "Example Sales Company", location: "Kisumu, Kenya", type: "Full-time", category: "Sales", description: "Sample listing for layout preview." },
  { title: "ICT Support Intern", company: "Example Tech Hub", location: "Thika, Kenya", type: "Internship", category: "Technology", description: "Sample listing for layout preview." },
  { title: "Community Project Assistant", company: "Example Community Organisation", location: "Machakos, Kenya", type: "Part-time", category: "Community", description: "Sample listing for layout preview." }
];

const $ = (selector) => document.querySelector(selector);
const jobsGrid = $("#jobsGrid");
const jobsStatus = $("#jobsStatus");
const authStatus = $("#authStatus");
const dialog = $("#infoDialog");

function showDialog(title, message) {
  $("#dialogTitle").textContent = title;
  $("#dialogText").textContent = message;
  if (typeof dialog.showModal === "function") dialog.showModal();
  else window.alert(`${title}\n\n${message}`);
}

function safeText(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function renderJobs(jobs) {
  jobsGrid.innerHTML = "";
  if (!jobs.length) {
    jobsGrid.innerHTML = '<div class="empty-state">No jobs match your search. Try another keyword or location.</div>';
    return;
  }
  for (const job of jobs) {
    const title = safeText(job.title || "Job opportunity");
    const company = safeText(job.company || job.company_name || "Employer");
    const location = safeText(job.location || "Kenya");
    const type = safeText(job.type || job.employment_type || "Opportunity");
    const category = safeText(job.category || "Job");
    const card = document.createElement("article");
    card.className = "job-card";
    card.innerHTML = `
      <div class="job-top"><div class="job-logo" aria-hidden="true">${title.charAt(0).toUpperCase()}</div><span class="job-type">${type}</span></div>
      <h3>${title}</h3><p class="job-company">${company}</p>
      <div class="job-meta"><span>📍 ${location}</span><span>• ${category}</span></div>
      <button class="button button-outline apply-button" type="button">View details</button>`;
    card.querySelector(".apply-button").addEventListener("click", () => {
      showDialog(title, `${company}\n${location}\n\n${job.description || "Check the employer's official application instructions before applying."}\n\nOnly apply through verified channels. Never pay an unverified recruiter.`);
    });
    jobsGrid.appendChild(card);
  }
}

async function loadJobs() {
  if (!supabaseClient) {
    renderJobs(sampleJobs);
    jobsStatus.textContent = "Demo listings only. Connect Supabase to display live jobs.";
    return;
  }
  try {
    // This query assumes a public jobs table with a published status. Adjust to match your actual columns.
    const { data, error } = await supabaseClient.from("jobs").select("*").eq("status", "published").order("created_at", { ascending: false }).limit(30);
    if (error) throw error;
    renderJobs((data || []).map((job) => ({
      title: job.title || job.job_title,
      company: job.company || job.company_name,
      location: job.location,
      type: job.type || job.employment_type,
      category: job.category,
      description: job.description
    })));
    jobsStatus.textContent = "Showing published listings from HUSTLEHUB.";
  } catch (error) {
    console.error("Could not load jobs:", error);
    renderJobs(sampleJobs);
    jobsStatus.textContent = "Could not load live jobs yet. Showing demo listings; check your table columns and RLS policies.";
  }
}

function initSupabase() {
  if (SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase?.createClient) {
    supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  }
}

$("#searchForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const keyword = $("#searchKeyword").value.trim().toLowerCase();
  const location = $("#searchLocation").value.trim().toLowerCase();
  const source = supabaseClient ? Array.from(jobsGrid.querySelectorAll(".job-card")).map(() => null).filter(Boolean) : sampleJobs;
  if (supabaseClient) {
    // Search rendered cards in place for connected results.
    const cards = Array.from(jobsGrid.querySelectorAll(".job-card"));
    let visible = 0;
    for (const card of cards) {
      const match = `${card.textContent}`.toLowerCase().includes(keyword) && `${card.textContent}`.toLowerCase().includes(location);
      card.hidden = !match;
      if (match) visible++;
    }
    let empty = jobsGrid.querySelector(".empty-state");
    if (!visible && !empty) {
      empty = document.createElement("div");
      empty.className = "empty-state";
      empty.textContent = "No jobs match your search. Try another keyword or location.";
      jobsGrid.appendChild(empty);
    } else if (visible && empty) empty.remove();
    jobsStatus.textContent = `${visible} matching listing(s) shown.`;
  } else {
    renderJobs(source.filter((job) => `${job.title} ${job.company} ${job.category}`.toLowerCase().includes(keyword) && job.location.toLowerCase().includes(location)));
    jobsStatus.textContent = "Search results from sample listings only.";
  }
});

document.querySelectorAll(".role-tab").forEach((button) => {
  button.addEventListener("click", () => {
    selectedRole = button.dataset.role;
    document.querySelectorAll(".role-tab").forEach((tab) => tab.classList.toggle("active", tab === button));
  });
});

async function authAction(action) {
  authStatus.textContent = "";
  const email = $("#authEmail").value.trim();
  const password = $("#authPassword").value;
  if (!email || !password) {
    authStatus.textContent = "Enter your email and password first.";
    return;
  }
  if (password.length < 8) {
    authStatus.textContent = "Use a password with at least 8 characters.";
    return;
  }
  if (!supabaseClient) {
    authStatus.textContent = "Supabase is not connected yet. We will connect it in the next setup step.";
    return;
  }
  try {
    let result;
    if (action === "signup") {
      result = await supabaseClient.auth.signUp({
        email, password,
        options: { data: { role: selectedRole } }
      });
    } else {
      result = await supabaseClient.auth.signInWithPassword({ email, password });
    }
    if (result.error) throw result.error;
    authStatus.textContent = action === "signup"
      ? "Registration submitted. Check your email if confirmation is required."
      : "You are logged in.";
  } catch (error) {
    authStatus.textContent = error.message || "Authentication failed. Check your Supabase settings.";
  }
}
$("#authForm").addEventListener("submit", (event) => { event.preventDefault(); authAction("signup"); });
$("#signInButton").addEventListener("click", () => authAction("signin"));
$("#loginNav").addEventListener("click", () => document.querySelector("#account").scrollIntoView({behavior:"smooth"}));
$("#registerNav").addEventListener("click", () => document.querySelector("#account").scrollIntoView({behavior:"smooth"}));
$("#heroRegister").addEventListener("click", () => document.querySelector("#account").scrollIntoView({behavior:"smooth"}));
$("#referralInfo").addEventListener("click", () => showDialog("Referral programme", "Referral links and rewards are not active in this starter version. We'll add them after account security, eligibility, and transparent reward rules are set."));
$("#closeDialog").addEventListener("click", () => dialog.close());
$("#dialogOk").addEventListener("click", () => dialog.close());
$("#menuToggle").addEventListener("click", () => {
  const nav = $("#navLinks");
  const open = nav.classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(open));
});
$("#navLinks").querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
  $("#navLinks").classList.remove("open");
  $("#menuToggle").setAttribute("aria-expanded", "false");
}));
$("#year").textContent = new Date().getFullYear();

initSupabase();
loadJobs();
