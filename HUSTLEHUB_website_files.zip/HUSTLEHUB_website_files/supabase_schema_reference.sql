-- REFERENCE ONLY. Do not run blindly: your Supabase project already has tables.
-- Inspect existing columns and policies first. This file is an example schema for a future clean project.
-- Keep Row Level Security enabled. Never create broad anonymous write policies.

create table if not exists public.jobs_example_reference (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  company_name text not null,
  location text not null,
  employment_type text,
  category text,
  description text not null,
  application_url text,
  status text not null default 'draft' check (status in ('draft','published','closed')),
  created_at timestamptz not null default now()
);

alter table public.jobs_example_reference enable row level security;

-- Add policies only after deciding who can publish jobs and what visitors may read.
-- Public SELECT should expose only published jobs; writes should be restricted to authorized admins.
